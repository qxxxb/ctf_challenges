# worm

## Description

### `frontend`
Server for launching a new instance. The intended exploit is not here.

### `instance`
The actual challenge instance. Pwn this :)

## Deploy

1. In `instance`, run `docker-compose build`
2. In `frontend`, run `docker-compose up`
