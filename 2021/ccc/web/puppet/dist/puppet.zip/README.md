# Puppet

## Description

### `frontend`
Web interface for launching a new instance. The intended exploit is not here.

### `instance`
The actual Puppeteer instance is launched here.

## Deploy

1. In `instance`, run `docker-compose build`
2. In `frontend`, run `docker-compose up`
